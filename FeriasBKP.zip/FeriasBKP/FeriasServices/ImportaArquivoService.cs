﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace FeriasServices
{
  public  class ImportaArquivoService : ServiceBase
    {
        public ImportaArquivoService(string apiBaseUrl)
        {
            ApiBaseUrl = apiBaseUrl;
        }

        public async Task<string> SaveImportedSheet([FromBody] string jsonProgramacao)
        {
            string Metodo = string.Concat("/Ferias/ImportarProgramacao");
            string Url = string.Concat(ApiBaseUrl, Metodo);
            string Retorno = string.Empty;
           

            var httpContent = new StringContent(jsonProgramacao, Encoding.UTF8, "application/json");

            using (var client = new HttpClient())
            {

                using (var response = await client.PostAsync(Url, httpContent))
                {
                    Retorno = response.IsSuccessStatusCode ? await response.Content.ReadAsStringAsync() : response.ReasonPhrase.ToString();
                }
            }

            return Retorno;
        }
    }
}
