﻿function Confirma(titulo, mensagem, textoBotaoConfirm, textoBotaoCancel, tipoIcone) {
    swal({
        title: titulo,
        text: mensagem,
        type: tipoIcone,
        showCancelButton: true,
        cancelButtonColor: "#DD0000",
        confirmButtonColor: "#00DD00",
        confirmButtonText: textoBotaoConfirm,
        cancelButtonText: textoBotaoCancel,
        closeOnConfirm: true,
        closeOnCancel: true
    },
        function (isConfirm) {
            if (isConfirm == true) {
                return true;
            }
            else {
                return false;
            }
        });
}  

function ShowModalMessage(message, title, icon) {
    swal({
        icon: icon,
        text: message,
        title: title,
        html: true
    });
}


function capitalizeFirstLetter(str) {

    // converting first letter to uppercase
    str = str.toLowerCase();
    const capitalized = str.replace(/^./, str[0].toUpperCase());

    return capitalized;
}


function capitalizeFirstLetterAllWords(str) {

    // converting first letter to uppercase
    var words = str.toLowerCase().split(' ');
    var capitalized = "";
    for (var i = 0; i < words.length; i++) {
        str = words[i];
        capitalized += str.replace(/^./, str[0].toUpperCase()) + ' ';
    }
    

    return capitalized;
}

function ValidarCpf (cpf, retornaFoco) {

    var exp = /\.|\-/g;
    var cpfValido = false;

   cpf = $('#' + cpf).val().replace(exp, '').toString();

    if (cpf.length == 0) {
        cpfValido = true;
    }
    if (cpf.length == 11) {

        var v = [];

        //Calcula o primeiro dígito de verificação.
        v[0] = 1 * cpf[0] + 2 * cpf[1] + 3 * cpf[2];
        v[0] += 4 * cpf[3] + 5 * cpf[4] + 6 * cpf[5];
        v[0] += 7 * cpf[6] + 8 * cpf[7] + 9 * cpf[8];
        v[0] = v[0] % 11;
        v[0] = v[0] % 10;

        //Calcula o segundo dígito de verificação.
        v[1] = 1 * cpf[1] + 2 * cpf[2] + 3 * cpf[3];
        v[1] += 4 * cpf[4] + 5 * cpf[5] + 6 * cpf[6];
        v[1] += 7 * cpf[7] + 8 * cpf[8] + 9 * v[0];
        v[1] = v[1] % 11;
        v[1] = v[1] % 10;

        //Retorna Verdadeiro se os dígitos de verificação são os esperados.

        if ((v[0] != cpf[9]) || (v[1] != cpf[10])) { ShowModalMessage('CPF inválido ==> ' + cpf, 'Validação', 'warning'); $('#' + cpf).val(''); }

        else if (cpf[0] == cpf[1] && cpf[1] == cpf[2] && cpf[2] == cpf[3] && cpf[3] == cpf[4] && cpf[4] == cpf[5] && cpf[5] == cpf[6] && cpf[6] == cpf[7] && cpf[7] == cpf[8] && cpf[8] == cpf[9] && cpf[9] == cpf[10]) { alert('CPF inválido ==> ' + cpf); $('#cpf').val(''); $('#cpf').focus(); }

        else { cpfValido = true;  }


    } else {
        ShowModalMessage('CPF inválido ==> ' + cpf, 'Validação', 'warning');
        $('#'+cpf).val('');
    } // 11
    if (retornaFoco) {
        $('#' + cpf).focus();
    }   
    return cpfValido;
}