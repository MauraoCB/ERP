﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using FeriasServices;
namespace WebFerias.Controllers
{
    public class ImportarArquivoController : Controller
    {
        private static string urlAPI = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build().GetSection("ApiBaseURL")["Ferias.API"];
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public JsonResult SaveImportedSheet(string jsonProgramacao)
        {
            try
            {
                ImportaArquivoService service = new ImportaArquivoService(urlAPI);
               var retorno = service.SaveImportedSheet(jsonProgramacao);
                 
                return Json(new { Success = true, StatusCode = "200", Message = "Programação importada com sucesso" });
            }
            catch (Exception ex)
            {
                return Json(new { Success = false, StatusCode = (int)HttpStatusCode.BadRequest, Message = ex.Message });
            }
        }
    }
}