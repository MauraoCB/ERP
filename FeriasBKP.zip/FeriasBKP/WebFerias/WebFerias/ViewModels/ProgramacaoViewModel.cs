﻿

using System;

namespace WebFerias.ViewModels
{
    public class ProgramacaoViewModel
    {
        public string NomeEstabelecimento { get; set; }
        public string Matricula { get; set; }
        public string Nome { get; set; }
        public string EscalaTurma { get; set; }
        public DateTime Admissao { get; set; }
        public string Situacao { get; set; }
        public string PeriodoAquisitivo { get; set; }
        public DateTime DataLimite { get; set; }
        public decimal QtdDias { get; set; }
        public int Meses { get; set; }
        public decimal SaldoDias { get; set; }
        public decimal DiasGozados { get; set; }
        public string Programacao { get; set; }
        public int Dias { get; set; }
        public int Abono { get; set; }
        public string DecimoTerceiroSalario { get; set; }
        public string CodigoCentroResultado { get; set; }
        public string NomeCentroResultado { get; set; }
        public string MatriculaChefia { get; set; }
        public string NomeChefia { get; set; }
        public string FeriasCompulsorias { get; set; }

    }
}
