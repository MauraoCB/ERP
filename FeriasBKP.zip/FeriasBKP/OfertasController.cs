﻿

using Atento.Horizon.BU.Administracao;
using Atento.Horizon.DTO.Administracao;
using Atento.Horizon.DTO.GPS;
using Swashbuckle.Swagger.Annotations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web.Http;

namespace Atento.Horizon.API.Controllers
{
    [RoutePrefix("api/Ofertas")]
    public class OfertasController : ApiController
    {
        [HttpPost]
        [Route("ImportarOfertas")]
        [SwaggerOperation("ImportarOfertas")]
        public IHttpActionResult ImportarOfertas([FromBody] List<OfertaDTO> OfertasImportacao)
        {
            bool gravaAlteracoes = false;

            try
            {
                gravaAlteracoes = new OfertasBU().ImportarOfertas(OfertasImportacao);

                return Ok();
            }
            catch (Exception ex)
            {
                return Content(HttpStatusCode.BadRequest, ex.Message);
            }
        }

        [HttpPost]
        [Route("SalvarOfertas")]
        [SwaggerOperation("SalvarOfertas")]
        public IHttpActionResult SalvarOfertas([FromBody] List<OfertaDTO> Ofertas)
        {
            bool gravaAlteracoes = false;

            try
            {
                gravaAlteracoes = new OfertasBU().SalvarOfertas(Ofertas);

                return Ok();
            }
            catch (Exception ex)
            {
                return Content(HttpStatusCode.BadRequest, ex.Message);
            }
        }

        [HttpPost]
        [Route("SalvarConfiguracaoOfertas")]
        [SwaggerOperation("SalvarConfiguracaoOfertas")]
        public IHttpActionResult SalvarConfiguracaoOfertas([FromBody] List<OfertaDTO> Ofertas)
        {
            bool gravaAlteracoes = false;

            try
            {
                gravaAlteracoes = new OfertasBU().SalvarConfiguracaoOfertas(Ofertas);

                return Ok();
            }
            catch (Exception ex)
            {
                return Content(HttpStatusCode.BadRequest, ex.Message);
            }
        }

        [HttpPost]
        [Route("SalvarTabulacaoOferta")]
        [SwaggerOperation("SalvarTabulacaoOferta")]
        public IHttpActionResult SalvarTabulacaoOferta([FromBody] TabulacaoOfertaDTO tabulacaoOferta)
        {
            bool gravaAlteracoes = false;

            try
            {
                gravaAlteracoes = new OfertasBU().SalvarTabulacaoOferta(tabulacaoOferta);

                return Ok();
            }
            catch (Exception ex)
            {
                return Content(HttpStatusCode.BadRequest, ex.Message);
            }
        }

        [HttpGet]
        [Route("GetOfertas/{operatioId}")]
        [SwaggerOperation("GetOfertas")]
        public List<OfertaDTO> GetOfertas(int operatioId)
        {
            return new OfertasBU().GetOfertas(operatioId);
        }

        [HttpGet]
        [Route("GetOferta/{numeroLinha}")]
        [SwaggerOperation("GetOferta")]
        public OfertaDTO GetOferta(string numeroLinha)
        {
            return new OfertasBU().GetOfertas().Where(o => o.NR_TLFN == numeroLinha && o.Status == "A").FirstOrDefault();
        }

        [HttpGet]
        [Route("GetOferta/{numeroLinha}/{operationId}")]
        [SwaggerOperation("GetOferta")]
        public OfertaDTO GetOferta(string numeroLinha, int operationId)
        {
            return new OfertasBU().GetOferta(numeroLinha, operationId);
        }

        [HttpGet]
        [Route("GetMensagem")]
        [SwaggerOperation("GetMensagem")]
        public string GetMensagem()
        {
            return new OfertasBU().GetMensagem();
        }
    }
}